# genoformerR/inst/python/train.py  (v0.3.0)
# Training loop for GenoFormer — lazy per-batch tensor materialisation.
#
# Key design change from v0.2:
#   Raw numpy arrays + split index vectors are received from R.
#   Tensors are built one batch at a time inside _make_batch(), so peak memory
#   is O(batch_size × M × K) rather than O(N × M × K).
#   The local_anc array (N × M × K) is the main beneficiary: for a typical
#   cohort of 2504 samples × 5816 SNPs × 5 pops in float32, the full tensor
#   is ~291 MB, but only ~7 MB enters GPU/CPU memory per batch of 64.

import numpy as np
import torch
import torch.nn.functional as F

# ── tqdm with graceful fallback ────────────────────────────────────────────────
try:
    from tqdm import tqdm as _tqdm
    _HAS_TQDM = True
except ImportError:
    _HAS_TQDM = False


# ── Loss functions ─────────────────────────────────────────────────────────────

def prs_loss(pred, true):
    return F.mse_loss(pred, true)


def pop_loss(logits, labels):
    # R NA_integer_ arrives as -2147483648 (INT32_MIN). Filter those rows so a
    # stray NA never reaches cross_entropy and produces a cryptic IndexError.
    valid = labels >= 0
    if not valid.all():
        logits = logits[valid]
        labels = labels[valid]
    if labels.numel() == 0:
        return torch.tensor(0.0, device=logits.device)
    return F.cross_entropy(logits, labels)


def ancestry_calibration_loss(pred_prs, true_prs, anc_probs, n_pops=5):
    """
    Penalise heteroscedastic residuals across populations.
    anc_probs: (B, K) global ancestry fractions.
    """
    residuals = pred_prs - true_prs
    total = torch.tensor(0.0, device=pred_prs.device)
    for k in range(n_pops):
        w     = anc_probs[:, k]
        w_sum = w.sum() + 1e-8
        mu_r  = (w * residuals).sum() / w_sum
        var_r = (w * (residuals - mu_r) ** 2).sum() / w_sum
        total = total + var_r
    return total / n_pops


# ── Core training entry point ─────────────────────────────────────────────────

def train_genoformer(model,
                     dosage_mat,
                     anc_probs,
                     log_beta,
                     ld_blocks,
                     chroms,
                     local_anc    = None,
                     prs_scaled   = None,
                     pop_labels   = None,
                     tr_idx       = None,
                     va_idx       = None,
                     device       = "cpu",
                     epochs       = 100,
                     batch_size   = 64,
                     lr           = 1e-4,
                     weight_decay = 0.01,
                     anc_weight   = 0.3,
                     calib_weight = 0.5,
                     save_path    = None,
                     verbose      = True,
                     progress_bar = True,
                     has_phenotype = True):
    """
    Train GenoFormer (v0.3) with lazy per-batch tensor materialisation.

    Parameters
    ----------
    dosage_mat  : numpy (N, M) float — passed as-is from R, cast to float32 here
    anc_probs   : numpy (N, K) float
    log_beta    : numpy (M,)   float — 1-D; tiled to (B, M) inside _make_batch
    ld_blocks   : numpy (M,)   int   — 1-D; tiled to (B, M) inside _make_batch
    chroms      : numpy (M,)   int   — 1-D; tiled to (B, M) inside _make_batch
    local_anc   : numpy (N, M, K) float or None
    prs_scaled  : numpy (N,)   float or None  (pre-scaled in R)
    pop_labels  : numpy (N,)   int   or None
    tr_idx      : numpy (n_tr,) int  — 0-based row indices for training split
    va_idx      : numpy (n_va,) int  — 0-based row indices for validation split
    has_phenotype : bool — when False, PRS + calibration losses are skipped
    progress_bar  : bool — show tqdm epoch bar (requires tqdm package)
    """
    # ── Cast all inputs to float32 / int64 once ────────────────────────────
    # R passes float64 by default; casting here halves the numpy memory footprint
    # before any batching begins.
    dosage_np   = np.asarray(dosage_mat, dtype=np.float32)
    anc_np      = np.asarray(anc_probs,  dtype=np.float32)
    log_beta_np = np.asarray(log_beta,   dtype=np.float32)   # (M,)
    ld_np       = np.asarray(ld_blocks,  dtype=np.int64)     # (M,)
    ch_np       = np.asarray(chroms,     dtype=np.int64)     # (M,)
    local_np    = np.asarray(local_anc,  dtype=np.float32) if local_anc  is not None else None
    prs_np      = np.asarray(prs_scaled, dtype=np.float32) if prs_scaled is not None else None
    pop_np      = np.asarray(pop_labels, dtype=np.int64)   if pop_labels is not None else None

    tr_idx = np.asarray(tr_idx, dtype=np.int64)
    va_idx = np.asarray(va_idx, dtype=np.int64)

    has_local = local_np is not None
    has_pop   = pop_np   is not None

    # Mode label used in progress display
    if not has_phenotype:
        mode_label = "ancestry-only"
    elif has_local:
        mode_label = "dual"
    else:
        mode_label = "global"

    # ── Lazy batch builder ─────────────────────────────────────────────────
    def _make_batch(idx):
        """
        Build tensors for a single batch from row indices.
        Only idx rows of the large arrays are touched; 1-D vectors are tiled
        here rather than once for the full split.
        """
        b_size = len(idx)
        batch  = {
            "dosage":     torch.from_numpy(dosage_np[idx]).to(device),
            # Tile 1-D vectors to (B, M) only for this batch
            "log_beta":   torch.from_numpy(
                              np.tile(log_beta_np, (b_size, 1))).to(device),
            "ld_block":   torch.from_numpy(
                              np.tile(ld_np,       (b_size, 1))).to(device),
            "chrom":      torch.from_numpy(
                              np.tile(ch_np,       (b_size, 1))).to(device),
            "global_anc": torch.from_numpy(anc_np[idx]).to(device),
        }
        if has_local:
            batch["local_anc"] = torch.from_numpy(local_np[idx]).to(device)
        if prs_np is not None:
            batch["prs"] = torch.from_numpy(prs_np[idx]).to(device)
        if has_pop:
            batch["pop"] = torch.from_numpy(pop_np[idx]).to(device)
        return batch

    def _iter_batches(idx_array, shuffle=True):
        """Yield index slices; materialise tensors only when consumed."""
        perm = np.random.permutation(len(idx_array)) if shuffle else np.arange(len(idx_array))
        idx_shuffled = idx_array[perm]
        for start in range(0, len(idx_shuffled), batch_size):
            yield _make_batch(idx_shuffled[start:start + batch_size])

    # ── Loss composition ───────────────────────────────────────────────────
    def _compute_loss(pred_prs, pop_logits, batch):
        total = torch.tensor(0.0, device=pred_prs.device)
        if has_phenotype and "prs" in batch:
            total = total + prs_loss(pred_prs, batch["prs"])
            total = total + calib_weight * ancestry_calibration_loss(
                        pred_prs, batch["prs"], batch["global_anc"])
        if has_pop and "pop" in batch:
            total = total + anc_weight * pop_loss(pop_logits, batch["pop"])
        return total

    # ── Optimiser & scheduler ──────────────────────────────────────────────
    opt   = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs, eta_min=1e-6)

    best_val = float("inf")
    history  = {"epoch": [], "train_loss": [], "val_loss": [], "lr": []}

    # ── Progress bar setup ─────────────────────────────────────────────────
    use_pbar = progress_bar and _HAS_TQDM
    if progress_bar and not _HAS_TQDM:
        print("[genoformerR] tqdm not found — install it for a progress bar "
              "(pip install tqdm). Falling back to verbose printing.")

    epoch_iter = _tqdm(
        range(1, epochs + 1),
        desc    = f"GenoFormer [{mode_label}]",
        unit    = "epoch",
        ncols   = 90,
        colour  = "cyan",
    ) if use_pbar else range(1, epochs + 1)

    # ── Training loop ──────────────────────────────────────────────────────
    for epoch in epoch_iter:

        # Train
        model.train()
        tr_loss, n_b = 0.0, 0
        for batch in _iter_batches(tr_idx, shuffle=True):
            pred_prs, pop_logits = model(
                batch["dosage"],  batch["log_beta"],
                batch["ld_block"], batch["chrom"],
                batch["global_anc"], batch.get("local_anc")
            )
            L = _compute_loss(pred_prs, pop_logits, batch)
            opt.zero_grad()
            L.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            tr_loss += L.item()
            n_b     += 1
        tr_loss /= max(n_b, 1)

        # Validate
        model.eval()
        va_loss, n_v = 0.0, 0
        with torch.no_grad():
            for batch in _iter_batches(va_idx, shuffle=False):
                pred_prs, pop_logits = model(
                    batch["dosage"],  batch["log_beta"],
                    batch["ld_block"], batch["chrom"],
                    batch["global_anc"], batch.get("local_anc")
                )
                L = _compute_loss(pred_prs, pop_logits, batch)
                va_loss += L.item()
                n_v     += 1
        va_loss /= max(n_v, 1)

        sched.step()
        cur_lr = sched.get_last_lr()[0]

        history["epoch"].append(epoch)
        history["train_loss"].append(round(tr_loss, 6))
        history["val_loss"].append(round(va_loss, 6))
        history["lr"].append(round(cur_lr, 8))

        # Checkpoint
        if va_loss < best_val:
            best_val = va_loss
            if save_path:
                torch.save(model.state_dict(), save_path)

        # Update tqdm postfix (live metrics in bar)
        if use_pbar:
            epoch_iter.set_postfix(
                train = f"{tr_loss:.4f}",
                val   = f"{va_loss:.4f}",
                lr    = f"{cur_lr:.1e}",
                best  = f"{best_val:.4f}",
            )

        # Verbose text fallback — every 10 epochs when no pbar
        if verbose and not use_pbar and epoch % 10 == 0:
            print(f"[{mode_label}] Epoch {epoch:4d} | "
                  f"train={tr_loss:.4f} | val={va_loss:.4f} | lr={cur_lr:.2e}")

    return {"history": history, "best_val_loss": best_val}
