# genoformerR/R/03_model.R
# Step 4–5: GenoFormer model construction and training via reticulate

#' Build the GenoFormer transformer model
#'
#' Constructs a GenoFormer v0.2 instance in Python/PyTorch via reticulate.
#' Supports dual-level ancestry conditioning: global ancestry (FiLM per block)
#' and local ancestry (per-SNP token embedding from RFMix2 posteriors).
#'
#' @param n_snps        Integer. Number of PGS SNPs (sequence length). Default 80000.
#' @param n_ld_blocks   Integer. Number of LD blocks (genome-wide ~1700). Default 1700.
#' @param d_model       Integer. Transformer hidden dimension. Default 256.
#' @param n_heads       Integer. Number of attention heads. Default 8.
#' @param n_layers      Integer. Transformer depth. Default 6.
#' @param anc_dim       Integer. Global ancestry dimension (5 superpops). Default 5.
#' @param k_pops        Integer. Number of reference populations in local ancestry
#'   posteriors (K in RFMix2 output). Must match \code{dim(local_anc_arr)[3]}.
#'   Default 5.
#' @param d_local       Integer. Projection dimension for local ancestry embedding.
#'   Larger values allow richer local ancestry representations. Default 64.
#' @param use_local_anc Logical. If FALSE, disables local ancestry embedding and
#'   the model behaves identically to v0.1 (global-only). Default TRUE.
#' @param pool_to_blocks Logical. If TRUE (default, strongly recommended),
#'   SNP embeddings are mean-pooled within each LD block before self-attention,
#'   reducing the attention sequence length from \code{n_snps} to
#'   \code{n_ld_blocks}. This cuts attention memory from O(n_snps²) to
#'   O(n_ld_blocks²) — a ~11.7× reduction for 5816 SNPs / 1700 blocks — and
#'   is required to avoid OOM on standard instances for any PGS with more than
#'   ~500 SNPs. Set to FALSE only for very small panels (n_snps ≤ 500).
#' @param dropout       Numeric. Dropout rate. Default 0.1.
#' @param device        Character. \code{"cuda"}, \code{"mps"}, or \code{"cpu"}.
#'   Auto-detected if \code{"auto"}.
#'
#' @return An S3 object of class \code{gf_model} wrapping the PyTorch module.
#' @export
#'
#' @examples
#' \dontrun{
#' gf_init()
#' # With local ancestry (RFMix2 K=3 pops: AFR, EUR, NAT)
#' model <- gf_build_model(n_snps = 5000, k_pops = 3, d_local = 32)
#' # Global-only fallback (v0.1 behaviour)
#' model <- gf_build_model(n_snps = 5000, use_local_anc = FALSE)
#' }
gf_build_model <- function(n_snps        = 80000L,
                            n_ld_blocks   = 1700L,
                            d_model       = 256L,
                            n_heads       = 8L,
                            n_layers      = 6L,
                            anc_dim       = 5L,
                            k_pops        = 5L,
                            d_local       = 64L,
                            use_local_anc = TRUE,
                            pool_to_blocks = TRUE,
                            dropout       = 0.1,
                            device        = "auto") {
  # Coerce all args — guards against list-typed values from jsonlite::read_json()
  n_snps        <- as.integer(n_snps)
  n_ld_blocks   <- as.integer(n_ld_blocks)
  d_model       <- as.integer(d_model)
  n_heads       <- as.integer(n_heads)
  n_layers      <- as.integer(n_layers)
  anc_dim       <- as.integer(anc_dim)
  k_pops        <- as.integer(k_pops)
  d_local       <- as.integer(d_local)
  dropout       <- as.numeric(dropout)
  use_local_anc <- isTRUE(as.logical(use_local_anc))
  pool_to_blocks <- isTRUE(as.logical(pool_to_blocks))

  .check_init()
  device <- .resolve_device(device)
  cli::cli_alert_info("Building GenoFormer v0.3 on {.val {device}} ...")
  if (use_local_anc)
    cli::cli_alert_info("Local ancestry: k_pops={k_pops}, d_local={d_local}")
  else
    cli::cli_alert_info("Local ancestry: disabled (global-only mode)")
  if (pool_to_blocks)
    cli::cli_alert_info(
      "Attention: LD-block pooling ({n_ld_blocks} tokens) — O(n_blocks\u00B2) memory"
    )
  else
    cli::cli_alert_warn(
      "Attention: full SNP-level ({n_snps} tokens) — O(n_snps\u00B2) memory. \\
       Will OOM for n_snps > ~500 on standard instances."
    )

  torch <- .gf_env$torch
  main  <- reticulate::import_main()

  model_py <- main$GenoFormer(
    n_snps        = n_snps,
    n_ld_blocks   = n_ld_blocks,
    d_model       = d_model,
    n_heads       = n_heads,
    n_layers      = n_layers,
    anc_dim       = anc_dim,
    k_pops        = k_pops,
    d_local       = d_local,
    dropout       = dropout,
    use_local_anc = use_local_anc,
    pool_to_blocks = pool_to_blocks
  )
  model_py <- model_py$to(device)

  # Assign model into Python main namespace so py_eval can see it,
  # then clean up afterwards
  main$`_gf_tmp_model` <- model_py
  n_params <- reticulate::py_to_r(
    reticulate::py_eval(
      "sum(p.numel() for p in _gf_tmp_model.parameters() if p.requires_grad)"
    )
  )
  main$`_gf_tmp_model` <- NULL

  result <- structure(
    list(
      model_py  = model_py,
      device    = device,
      n_params  = n_params,
      config    = list(n_snps = n_snps, n_ld_blocks = n_ld_blocks,
                       d_model = d_model, n_heads = n_heads,
                       n_layers = n_layers, anc_dim = anc_dim,
                       k_pops = k_pops, d_local = d_local,
                       use_local_anc = use_local_anc,
                       pool_to_blocks = pool_to_blocks,
                       dropout = dropout)
    ),
    class = c("gf_model", "list")
  )
  cli::cli_alert_success(
    "GenoFormer ready: {.val {format(n_params, big.mark=',')}} parameters on {.val {device}}"
  )
  result
}


#' @export
print.gf_model <- function(x, ...) {
  cli::cli_h1("GenoFormer Model (v0.2)")
  cfg <- x$config
  cli::cli_dl(c(
    "Device"          = x$device,
    "Parameters"      = format(x$n_params, big.mark = ","),
    "SNPs (L)"        = format(cfg$n_snps,      big.mark = ","),
    "d_model"         = cfg$d_model,
    "Layers"          = cfg$n_layers,
    "Heads"           = cfg$n_heads,
    "LD blocks"       = cfg$n_ld_blocks,
    "Global anc dim"  = cfg$anc_dim,
    "Local anc (K)"   = if (cfg$use_local_anc) cfg$k_pops  else "disabled",
    "Local anc (dim)" = if (cfg$use_local_anc) cfg$d_local else "disabled",
    "Attention over"  = if (isTRUE(cfg$pool_to_blocks))
                          paste0("LD blocks (", cfg$n_ld_blocks, " tokens)")
                        else
                          paste0("all SNPs  (", cfg$n_snps, " tokens) \u26a0 OOM risk")
  ))
  invisible(x)
}


#' Train the GenoFormer model
#'
#' Runs multi-task training with two modes depending on phenotype availability:
#'
#' \strong{Full mode} (default, \code{phenotype} provided): PRS regression (MSE)
#' + ancestry classification (cross-entropy) + ancestry calibration loss.
#'
#' \strong{Ancestry-only mode} (\code{phenotype = NULL}): only ancestry
#' classification loss is used. The model learns ancestry-conditioned
#' representations from global PCA and (optionally) local ancestry posteriors
#' without any phenotype supervision. Useful for pre-training or when phenotype
#' data are unavailable. \code{pop_labels} must still be provided in this mode.
#'
#' Accepts an optional \code{local_anc} array (N × M × K) from RFMix2/FLARE
#' for dual-level conditioning. When provided, local ancestry is passed as a
#' per-SNP tensor alongside the global ancestry vector.
#'
#' @param model        A \code{gf_model} object from \code{\link{gf_build_model}}.
#' @param dosage_mat   Numeric matrix (N × M) of dosage values.
#' @param anc_probs    Numeric matrix (N × 5) of global soft ancestry proportions
#'   from \code{\link{gf_ancestry}}.
#' @param pgs_weights  Numeric vector (M). Effect weights from PGS scoring file.
#' @param ld_blocks    Integer vector (M). LD block assignment per SNP.
#' @param chroms       Integer vector (M). Chromosome per SNP.
#' @param phenotype    Numeric vector (N) or \code{NULL}. Continuous or binary
#'   phenotype. When \code{NULL}, training runs in ancestry-only mode: only
#'   ancestry classification loss is optimised (PRS and calibration losses are
#'   skipped). Default \code{NULL}.
#' @param pop_labels   Integer vector (N) or \code{NULL}. Superpopulation integer
#'   codes (0–4). Required when \code{phenotype = NULL} (ancestry-only mode);
#'   optional but recommended otherwise. Default \code{NULL}.
#' @param local_anc    Numeric array (N × M × K) of per-SNP local ancestry
#'   posteriors from \code{\link{gf_load_local_anc}}, or NULL to disable local
#'   ancestry conditioning (global-only mode). Default NULL.
#' @param epochs       Integer. Training epochs. Default 100.
#' @param batch_size   Integer. Mini-batch size. Default 64.
#' @param lr           Numeric. Initial learning rate. Default 1e-4.
#' @param weight_decay Numeric. AdamW weight decay. Default 0.01.
#' @param anc_weight   Numeric. Ancestry classification loss weight. Default 0.3.
#' @param calib_weight Numeric. Calibration loss weight. Default 0.5.
#' @param val_split    Numeric. Fraction held out for validation. Default 0.1.
#' @param save_path    Character or NULL. Where to save the best checkpoint.
#' @param verbose      Logical. Print epoch-level loss summary every 10 epochs.
#'   Default TRUE.
#' @param progress_bar Logical. Show a live tqdm progress bar over epochs with
#'   per-epoch train/val loss and learning rate. Default TRUE. Can be combined
#'   with \code{verbose}; set both to FALSE for silent training.
#'
#' @return A list with \code{model} and \code{history} (data frame).
#' @export
gf_train <- function(model,
                     dosage_mat,
                     anc_probs,
                     pgs_weights,
                     ld_blocks,
                     chroms,
                     phenotype    = NULL,
                     pop_labels   = NULL,
                     local_anc    = NULL,
                     epochs       = 100L,
                     batch_size   = 64L,
                     lr           = 1e-4,
                     weight_decay = 0.01,
                     anc_weight   = 0.3,
                     calib_weight = 0.5,
                     val_split    = 0.1,
                     save_path    = "genoformer_best.pt",
                     verbose      = TRUE,
                     progress_bar = TRUE) {
  .check_init()
  stopifnot(inherits(model, "gf_model"))

  # ── Mode detection ─────────────────────────────────────────────────────────
  has_phenotype <- !is.null(phenotype)
  if (!has_phenotype) {
    if (is.null(pop_labels)) {
      cli::cli_abort(
        c("Ancestry-only mode requires {.arg pop_labels}.",
          "i" = "Provide integer population codes (0-4) even when {.arg phenotype} is NULL.")
      )
    }
    cli::cli_alert_info(
      "Ancestry-only mode: {.arg phenotype} is NULL. \\
       Training with ancestry classification loss only (PRS + calibration losses skipped)."
    )
  } else {
    if (is.null(pop_labels)) {
      cli::cli_warn(
        "{.arg pop_labels} not provided. Ancestry classification loss will be skipped."
      )
    }
  }

  # ── pop_labels validation ───────────────────────────────────────────────────
  # R encodes NA_integer_ as INT32_MIN (-2147483648). PyTorch cross_entropy
  # treats class indices as unsigned, so any NA reaches Python as an out-of-
  # bounds target and throws "Target -2147483648 is out of bounds".
  if (!is.null(pop_labels)) {
    pop_labels <- as.integer(pop_labels)
    na_idx     <- which(is.na(pop_labels))
    if (length(na_idx) > 0L) {
      cli::cli_abort(c(
        "{.arg pop_labels} contains {length(na_idx)} NA value{?s} \\
         (sample{?s} {na_idx[seq_len(min(5L, length(na_idx)))]}{?...}).",
        "i" = "All samples must have a valid superpopulation code (0-4).",
        "i" = "To exclude samples with unknown ancestry, subset your data \\
               before calling {.fn gf_train}."
      ))
    }
    bad_codes <- unique(pop_labels[pop_labels < 0L | pop_labels > 4L])
    if (length(bad_codes) > 0L) {
      cli::cli_abort(c(
        "{.arg pop_labels} contains out-of-range code{?s}: {bad_codes}.",
        "i" = "Valid superpopulation codes are integers 0 (AFR), 1 (AMR), \\
               2 (EAS), 3 (EUR), 4 (SAS)."
      ))
    }
  }

  # ── phenotype NA check ──────────────────────────────────────────────────────
  if (has_phenotype) {
    na_pheno <- sum(is.na(phenotype))
    if (na_pheno > 0L) {
      cli::cli_abort(c(
        "{.arg phenotype} contains {na_pheno} NA value{?s}.",
        "i" = "Remove or impute missing phenotype values before training."
      ))
    }
  }

  use_local <- !is.null(local_anc) && model$config$use_local_anc
  if (use_local) {
    stopifnot(
      is.array(local_anc),
      length(dim(local_anc)) == 3L,
      dim(local_anc)[1] == nrow(dosage_mat),
      dim(local_anc)[2] == ncol(dosage_mat)
    )
    K_local <- dim(local_anc)[3]
    if (K_local != model$config$k_pops) {
      cli::cli_abort(
        "local_anc has K={K_local} populations but model was built with k_pops={model$config$k_pops}."
      )
    }
    cli::cli_alert_info("Dual-level conditioning: global ancestry + local ancestry (K={K_local})")
  } else {
    cli::cli_alert_info("Global-only conditioning (local_anc not provided or disabled in model)")
  }

  torch <- .gf_env$torch
  main  <- reticulate::import_main()

  cli::cli_h1("GenoFormer Training")
  cli::cli_alert_info("Epochs={epochs} | batch={batch_size} | lr={lr}")

  # ── Train / val split ──────────────────────────────────────────────────────
  N     <- nrow(dosage_mat)
  val_n <- max(1L, floor(N * val_split))
  idx   <- sample.int(N)
  val_i <- idx[seq_len(val_n)]
  tr_i  <- idx[-seq_len(val_n)]

  cli::cli_alert_info(
    "Split: {length(tr_i)} train / {length(val_i)} val samples"
  )

  # ── Pre-compute static embedding cache (once per training run) ───────────
  # This pools log_beta, ld_emb, chr_emb to block level and caches the result.
  # Eliminates ~573 MB/batch of redundant tensor copies for those static inputs.
  gf_cache_static_embedding(model, pgs_weights, ld_blocks, chroms)

  # ── Pre-compute 1-D derived vectors (not tiled — Python tiles per batch) ──
  log_beta   <- log(abs(pgs_weights) + 1e-8)           # (M,) float
  prs_scaled <- if (has_phenotype) as.numeric(scale(phenotype)) else NULL

  # ── Pass raw R arrays to Python; all float32 casting done there ───────────
  # No full-cohort tensor materialisation here — Python builds one batch at a
  # time, keeping peak memory at O(batch_size × M × K) rather than O(N × M × K).
  result_py <- main$train_genoformer(
    model        = model$model_py,
    dosage_mat   = reticulate::r_to_py(dosage_mat),
    anc_probs    = reticulate::r_to_py(anc_probs),
    log_beta     = reticulate::r_to_py(log_beta),
    ld_blocks    = reticulate::r_to_py(as.integer(ld_blocks)),
    chroms       = reticulate::r_to_py(as.integer(chroms)),
    local_anc    = if (use_local) reticulate::r_to_py(local_anc) else reticulate::py_none(),
    prs_scaled   = if (has_phenotype) reticulate::r_to_py(prs_scaled) else reticulate::py_none(),
    pop_labels   = if (!is.null(pop_labels)) reticulate::r_to_py(as.integer(pop_labels)) else reticulate::py_none(),
    tr_idx       = reticulate::r_to_py(as.integer(tr_i  - 1L)),   # 0-indexed
    va_idx       = reticulate::r_to_py(as.integer(val_i - 1L)),
    device       = model$device,
    epochs       = as.integer(epochs),
    batch_size   = as.integer(batch_size),
    lr           = lr,
    weight_decay = weight_decay,
    anc_weight   = anc_weight,
    calib_weight = calib_weight,
    save_path    = if (is.null(save_path)) reticulate::py_none() else save_path,
    verbose      = verbose,
    progress_bar = progress_bar,
    has_phenotype = has_phenotype
  )

  history <- as.data.frame(reticulate::py_to_r(result_py$history))

  if (!is.null(save_path) && file.exists(save_path)) {
    model$model_py$load_state_dict(torch$load(save_path))
    cli::cli_alert_success("Best checkpoint loaded from {.path {save_path}}")
  }

  cli::cli_alert_success(
    "Training complete. Best val loss: {.val {round(min(history$val_loss), 4)}}"
  )
  list(model = model, history = history)
}


#' Pre-compute and cache the static SNP embedding for faster training
#'
#' Pools the static components of the SNP embedding (log|β|, LD block identity,
#' chromosome) from SNP level (L positions) to LD block level (n_ld_blocks
#' positions) and caches the result inside the model. This eliminates ~573 MB
#' of redundant tensor copies per batch and reduces the dominant fusion linear
#' from O(L) to O(n_ld_blocks) operations.
#'
#' Called automatically by \code{\link{gf_train}} when \code{pgs_weights},
#' \code{ld_blocks}, and \code{chroms} are provided. Expose here for users who
#' want to call it manually (e.g. after loading a model for fine-tuning).
#'
#' @param model       A \code{gf_model} object.
#' @param pgs_weights Numeric vector (M). Effect weights (same as passed to \code{gf_train}).
#' @param ld_blocks   Integer vector (M). LD block IDs.
#' @param chroms      Integer vector (M). Chromosome per SNP.
#' @return The \code{gf_model} object invisibly (cache stored in-place on the Python side).
#' @export
gf_cache_static_embedding <- function(model, pgs_weights, ld_blocks, chroms) {
  .check_init()
  stopifnot(inherits(model, "gf_model"))
  torch    <- .gf_env$torch
  log_beta <- log(abs(pgs_weights) + 1e-8)
  model$model_py$embed$precompute_static_embedding(
    torch$tensor(reticulate::r_to_py(as.numeric(log_beta)),  dtype = torch$float32),
    torch$tensor(reticulate::r_to_py(as.integer(ld_blocks)), dtype = torch$int64),
    torch$tensor(reticulate::r_to_py(as.integer(chroms)),    dtype = torch$int64)
  )
  cli::cli_alert_success("Static embedding cache ready ({length(ld_blocks)} SNPs \u2192 {model$config$n_ld_blocks} blocks)")
  invisible(model)
}


#' Save a trained GenoFormer model
#'
#' @param model      A \code{gf_model} object.
#' @param path       Character. Output \code{.pt} file path.
#' @param save_config Logical. Also save JSON config alongside the weights.
#' @export
gf_save_model <- function(model, path = "genoformer.pt", save_config = TRUE) {
  .check_init()
  .gf_env$torch$save(model$model_py$state_dict(), path)
  if (save_config) {
    cfg_path <- sub("\\.pt$", "_config.json", path)
    jsonlite::write_json(model$config, cfg_path, pretty = TRUE)
  }
  cli::cli_alert_success("Model saved to {.path {path}}")
  invisible(path)
}


#' Load a saved GenoFormer model
#'
#' @param path   Character. Path to \code{.pt} weights file.
#' @param config Named list or path to JSON config. If NULL, uses defaults.
#' @param device Character. Device for inference.
#' @export
gf_load_model <- function(path, config = NULL, device = "auto") {
  .check_init()
  if (is.null(config)) {
    cfg_path <- sub("\\.pt$", "_config.json", path)
    if (file.exists(cfg_path)) {
      config <- jsonlite::read_json(cfg_path)
    }
  }
  args <- if (is.null(config)) list() else .sanitise_config(config)
  model <- do.call(gf_build_model, c(args, list(device = device)))
  model$model_py$load_state_dict(.gf_env$torch$load(path))
  cli::cli_alert_success("Weights loaded from {.path {path}}")
  model
}


# ─── Internal helpers ──────────────────────────────────────────────────────────

# Flatten any list-typed values produced by jsonlite::read_json() and coerce
# each config field to the expected scalar type.
.sanitise_config <- function(cfg) {
  scalar <- function(x) if (is.list(x)) x[[1]] else x
  list(
    n_snps        = as.integer(scalar(cfg$n_snps)),
    n_ld_blocks   = as.integer(scalar(cfg$n_ld_blocks)),
    d_model       = as.integer(scalar(cfg$d_model)),
    n_heads       = as.integer(scalar(cfg$n_heads)),
    n_layers      = as.integer(scalar(cfg$n_layers)),
    anc_dim       = as.integer(scalar(cfg$anc_dim)),
    k_pops        = as.integer(scalar(cfg$k_pops)),
    d_local       = as.integer(scalar(cfg$d_local)),
    dropout       = as.numeric(scalar(cfg$dropout)),
    use_local_anc  = isTRUE(as.logical(scalar(cfg$use_local_anc))),
    pool_to_blocks = isTRUE(as.logical(scalar(cfg$pool_to_blocks %||% TRUE)))
  )
}

.resolve_device <- function(device) {
  if (device != "auto") return(device)
  torch <- .gf_env$torch
  if (reticulate::py_to_r(torch$cuda$is_available())) return("cuda")
  if (reticulate::py_to_r(torch$backends$mps$is_available())) return("mps")
  "cpu"
}

# Null-coalescing: x %||% default returns default when x is NULL
`%||%` <- function(x, y) if (is.null(x)) y else x
