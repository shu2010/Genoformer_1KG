# genoformerR/inst/python/model.py  (v0.5.0)
# GenoFormer PyTorch model with dual-level ancestry conditioning.
#
# v0.5 — EUR-distance LD-attenuation of effect sizes (unsupervised signal):
#
#   Motivation: EUR GWAS summary statistics estimate β_tag = β_causal × r²(tag,causal)_EUR.
#   When a sample has non-EUR local ancestry at a locus, the tag-to-causal LD
#   may differ, making β_EUR a biased estimate.  Multiplying log|β| by
#   P(EUR | sample, window) before beta_proj encodes this LD-attenuation
#   hypothesis directly in the token representation, without requiring phenotypes.
#   The supervised FiLM layers then learn any residual ancestry-specific
#   corrections (true effect heterogeneity) on top.
#
#   Implementation consequence: beta_proj is now sample-specific when EUR
#   attenuation is active (each sample has a different EUR probability per SNP).
#   Therefore beta_proj can NO LONGER be included in the static embedding cache.
#
#   Cache contents:
#     EUR attenuation OFF:  lb + ld + ch  →  (1, n_blocks, 3q)   [v0.4 behaviour]
#     EUR attenuation ON:   ld + ch only  →  (1, n_blocks, 2q)   [v0.5]
#     beta_block computed per-batch from EUR-attenuated log_beta  [v0.5]
#
#   Total token dimensionality entering fusion is 4q = d_model in both cases,
#   so the fusion layer weight shape is unchanged.
#
# v0.4 performance fix — pool-then-fuse + static embedding cache:
#   v0.3 order:  embed all L SNPs → fuse at L positions → pool to B blocks
#   v0.4 order:  project cheap per-SNP components → pool to B blocks → fuse at B positions
#   Memory and FLOP comparison at B=32, L=5816, n_blocks=1700, d_model=256:
#     v0.3 fusion:  32 × 5816 × 320 × 256 =  15.2 GFLOP/batch
#     v0.4 fusion:  32 × 1700 × 320 × 256 =   4.5 GFLOP/batch  (3.4× less)

import torch
import torch.nn as nn
import torch.nn.functional as F


# ── Conditioning modules ───────────────────────────────────────────────────────

class AncestryFiLM(nn.Module):
    """FiLM conditioning on global ancestry — applied to each transformer block."""
    def __init__(self, anc_dim: int, hidden_dim: int):
        super().__init__()
        self.gamma = nn.Linear(anc_dim, hidden_dim)
        self.beta  = nn.Linear(anc_dim, hidden_dim)
        nn.init.ones_(self.gamma.weight);  nn.init.zeros_(self.gamma.bias)
        nn.init.zeros_(self.beta.weight);  nn.init.zeros_(self.beta.bias)

    def forward(self, x, global_anc):
        g = self.gamma(global_anc).unsqueeze(1)
        b = self.beta(global_anc).unsqueeze(1)
        return g * x + b


class LocalAncestryProjector(nn.Module):
    """Per-SNP local ancestry projection: (B, L, K) -> (B, L, d_local)."""
    def __init__(self, k_pops: int, d_local: int):
        super().__init__()
        self.proj = nn.Sequential(
            nn.Linear(k_pops, d_local),
            nn.GELU(),
            nn.Linear(d_local, d_local)
        )

    def forward(self, local_anc):
        return self.proj(local_anc)


# ── LD-block pooling ───────────────────────────────────────────────────────────

def _pool_snps_to_blocks(x, ld_block_ids, n_ld_blocks):
    """
    Mean-pool SNP-level features within each LD block.

    x             : (B, L, D) or (1, L, D)
    ld_block_ids  : (B, L) int64  — 1-based IDs
    n_ld_blocks   : int

    Returns       : (B, n_ld_blocks, D)
    """
    B, L, D = x.shape
    ids     = (ld_block_ids - 1).clamp(min=0, max=n_ld_blocks - 1)  # (B, L)
    ids_exp = ids.unsqueeze(-1).expand(B, L, D).contiguous()

    pooled = x.new_zeros(B, n_ld_blocks, D)
    counts = x.new_zeros(B, n_ld_blocks, 1)
    pooled.scatter_add_(1, ids_exp, x)
    counts.scatter_add_(1, ids.unsqueeze(-1).contiguous(),
                        torch.ones(B, L, 1, device=x.device, dtype=x.dtype))
    return pooled / counts.clamp(min=1.0)


# ── SNP embedding with pool-then-fuse ─────────────────────────────────────────

class SNPEmbedding(nn.Module):
    """
    Token embedding for each SNP position — v0.5 pool-then-fuse with EUR attenuation.

    Processing order:
      1. Dosage: project at SNP level → pool to blocks             (B, L, q) → (B, n_blocks, q)
      2. EUR-attenuated log|β|: log_beta × P(EUR|sample,snp) →    (B, L, 1) → beta_proj
         project at SNP level → pool to blocks                     (B, L, q) → (B, n_blocks, q)
         When EUR attenuation is OFF, beta_proj uses raw log_beta and can
         be pre-pooled into the static cache (v0.4 behaviour).
      3. LD block embedding + chrom embedding: static              (L,q) + (L,q), pooled once
      4. Concatenate [dos | beta | ld | chr] at block level        → (B, n_blocks, 4q = d_model)
      5. Optional: pool local_anc (B,L,K) → (B,n_blocks,K), project to d_local
      6. Fuse: Linear(d_model [+d_local] → d_model) + LayerNorm   → (B, n_blocks, d_model)

    Static cache contents:
      EUR attenuation OFF:  [lb + ld + ch] → (1, n_blocks, 3q)   (v0.4 behaviour)
      EUR attenuation ON:   [ld + ch] only → (1, n_blocks, 2q)   (beta_proj computed per-batch)

    Total dimensions into fusion are 4q = d_model in both cases.
    """
    def __init__(self, n_ld_blocks, n_chrom, d_model, k_pops=0, d_local=0,
                 eur_pop_idx=-1):
        super().__init__()
        self.n_ld_blocks      = n_ld_blocks
        self.d_model          = d_model
        quarter               = d_model // 4
        self._quarter         = quarter

        # EUR-distance LD-attenuation flag.
        # Active when local ancestry is available (k_pops > 0) AND a valid
        # EUR population index is given.  When active, beta_proj receives
        # log_beta × P(EUR|sample,snp) rather than raw log_beta.
        self.use_eur_attenuation = (k_pops > 0) and (0 <= eur_pop_idx < k_pops)
        self.eur_pop_idx         = int(eur_pop_idx)

        # Per-SNP projections
        self.dosage_proj = nn.Linear(1, quarter)   # always sample-specific
        self.beta_proj   = nn.Linear(1, quarter)   # sample-specific when EUR atten. ON
        self.ld_emb      = nn.Embedding(n_ld_blocks + 1, quarter, padding_idx=0)
        self.chr_emb     = nn.Embedding(n_chrom + 1,     quarter, padding_idx=0)

        # Block-level fusion
        self.use_local_anc = k_pops > 0 and d_local > 0
        if self.use_local_anc:
            self.local_proj = LocalAncestryProjector(k_pops, d_local)
            self.fusion = nn.Sequential(
                nn.Linear(d_model + d_local, d_model),
                nn.LayerNorm(d_model)
            )
        else:
            self.fusion = nn.Sequential(
                nn.Linear(d_model, d_model),
                nn.LayerNorm(d_model)
            )

        # Cache slot for pooled static embeddings.
        # EUR attenuation OFF → (1, n_blocks, 3q)  [lb + ld + ch]
        # EUR attenuation ON  → (1, n_blocks, 2q)  [ld + ch only]
        self.register_buffer("_static_block_cache", None, persistent=False)

    @torch.no_grad()
    def precompute_static_embedding(self, log_beta_1d, ld_block_1d, chrom_1d):
        """
        Pre-pool static embedding components to block level and cache.

        When EUR attenuation is OFF:  caches [lb, ld, ch] → (1, n_blocks, 3q).
        When EUR attenuation is ON:   log_beta_1d is ignored; caches [ld, ch]
                                      → (1, n_blocks, 2q).  beta_proj must be
                                      computed per-batch from EUR-attenuated values.

        Parameters (all 1-D, shape (L,)):
          log_beta_1d : float32 tensor  — ignored when EUR attenuation is ON
          ld_block_1d : int64  tensor   (1-based block IDs)
          chrom_1d    : int64  tensor
        """
        dev  = next(self.parameters()).device
        ids1 = ld_block_1d.to(dev).unsqueeze(0)   # (1, L)

        ld = self.ld_emb(ld_block_1d.to(dev))     # (L, q)
        ch = self.chr_emb(chrom_1d.to(dev))       # (L, q)

        if self.use_eur_attenuation:
            # beta_proj is sample-specific → exclude from cache
            ldc_snp   = torch.cat([ld, ch], dim=-1).unsqueeze(0)  # (1, L, 2q)
            self._static_block_cache = _pool_snps_to_blocks(
                ldc_snp, ids1, self.n_ld_blocks)                   # (1, n_blocks, 2q)
        else:
            lb = self.beta_proj(log_beta_1d.to(dev).unsqueeze(-1)) # (L, q)
            static_snp = torch.cat([lb, ld, ch], dim=-1).unsqueeze(0)  # (1, L, 3q)
            self._static_block_cache = _pool_snps_to_blocks(
                static_snp, ids1, self.n_ld_blocks)                # (1, n_blocks, 3q)

    def forward(self, dosage, log_beta, ld_block, chrom, local_anc=None):
        """
        dosage   : (B, L, 1)
        log_beta : (B, L, 1)  — always needed (used for EUR attenuation or cache-miss fallback)
        ld_block : (B, L)     — always needed for dosage/beta pooling
        chrom    : (B, L)     or (B, 1) sentinel when cache is warm & no EUR atten.
        local_anc: (B, L, K) or None
        """
        B = dosage.shape[0]

        # ── 1. Dosage → project → pool ────────────────────────────────────
        dos_snp   = self.dosage_proj(dosage)                        # (B, L, q)
        dos_block = _pool_snps_to_blocks(dos_snp, ld_block,
                                         self.n_ld_blocks)          # (B, n_blocks, q)

        # ── 2. beta_proj: EUR-attenuated (sample-specific) or static ──────
        if self.use_eur_attenuation and local_anc is not None:
            # EUR-distance LD-attenuation: scale log|β| by P(EUR | sample, snp)
            # before projecting.  Variants in non-EUR local ancestry background
            # receive a down-weighted effect size contribution.
            eur_w      = local_anc[:, :, self.eur_pop_idx].unsqueeze(-1)  # (B, L, 1)
            beta_snp   = self.beta_proj(log_beta * eur_w)                 # (B, L, q)
            beta_block = _pool_snps_to_blocks(beta_snp, ld_block,
                                              self.n_ld_blocks)            # (B, n_blocks, q)
        else:
            # Static path: use cache if available, else recompute
            if self._static_block_cache is not None and not self.use_eur_attenuation:
                # Cache holds [lb + ld + ch] (3q) — extract beta slice (first q dims)
                beta_block = self._static_block_cache.expand(
                    B, -1, -1)[:, :, :self._quarter]                # (B, n_blocks, q)
            else:
                beta_snp   = self.beta_proj(log_beta)               # (B, L, q)
                beta_block = _pool_snps_to_blocks(beta_snp, ld_block,
                                                  self.n_ld_blocks)

        # ── 3. LD + chrom: from cache or recompute ────────────────────────
        if self._static_block_cache is not None:
            if self.use_eur_attenuation:
                # Cache holds [ld + ch] only (2q)
                ldc_block = self._static_block_cache.expand(B, -1, -1)  # (B, n_blocks, 2q)
            else:
                # Cache holds [lb + ld + ch] (3q) — extract ld+ch slice
                ldc_block = self._static_block_cache.expand(
                    B, -1, -1)[:, :, self._quarter:]                # (B, n_blocks, 2q)
        else:
            ld = self.ld_emb(ld_block)                              # (B, L, q)
            ch = self.chr_emb(chrom)                                # (B, L, q)
            ldc_snp   = torch.cat([ld, ch], dim=-1)                 # (B, L, 2q)
            ldc_block = _pool_snps_to_blocks(ldc_snp, ld_block,
                                             self.n_ld_blocks)      # (B, n_blocks, 2q)

        # ── 4. Concatenate all block-level components → d_model ───────────
        # [dos | beta | ld | chr] = [q + q + q + q] = [4q] = [d_model]
        x = torch.cat([dos_block, beta_block, ldc_block], dim=-1)  # (B, n_blocks, d_model)

        # ── 5. Optional: local ancestry projected + pooled to blocks ──────
        if self.use_local_anc and local_anc is not None:
            la_snp   = self.local_proj(local_anc)                   # (B, L, d_local)
            la_block = _pool_snps_to_blocks(la_snp, ld_block,
                                            self.n_ld_blocks)       # (B, n_blocks, d_local)
            x = torch.cat([x, la_block], dim=-1)                    # (B, n_blocks, d_model+d_local)

        # ── 6. Fuse at block level (Linear + LayerNorm) ───────────────────
        return self.fusion(x)                                        # (B, n_blocks, d_model)


# ── Transformer block ──────────────────────────────────────────────────────────

class GenoFormerBlock(nn.Module):
    """Transformer block with global ancestry FiLM on attention residual."""
    def __init__(self, d_model, n_heads, anc_dim, dropout=0.1):
        super().__init__()
        self.attn  = nn.MultiheadAttention(d_model, n_heads,
                                            dropout=dropout, batch_first=True)
        self.film  = AncestryFiLM(anc_dim, d_model)
        self.ff    = nn.Sequential(
            nn.Linear(d_model, d_model * 4), nn.GELU(),
            nn.Dropout(dropout), nn.Linear(d_model * 4, d_model)
        )
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)

    def forward(self, x, global_anc, attn_mask=None):
        attn_out, _ = self.attn(x, x, x, attn_mask=attn_mask)
        x = self.norm1(x + self.film(attn_out, global_anc))
        x = self.norm2(x + self.ff(x))
        return x


# ── Main model ─────────────────────────────────────────────────────────────────

class GenoFormer(nn.Module):
    """
    GenoFormer v0.5 — dual-level ancestry-aware PRS transformer.

    v0.5 adds EUR-distance LD-attenuation of effect sizes (see SNPEmbedding).
    eur_pop_idx: 0-based index of the EUR population in the local ancestry K dim.
      Default 3 (AFR=0, AMR=1, EAS=2, EUR=3, SAS=4). Set to -1 to disable.

    v0.4 change: pool-then-fuse embedding (see SNPEmbedding docstring).
    self-attention operates over n_ld_blocks tokens (not n_snps).
    pool_to_blocks is always True; the flag is retained for API compatibility.
    """
    def __init__(self,
                 n_snps=80_000, n_ld_blocks=1_700, n_chrom=22,
                 d_model=256, n_heads=8, n_layers=6,
                 anc_dim=5, k_pops=5, d_local=64,
                 dropout=0.1, use_local_anc=True,
                 pool_to_blocks=True,
                 eur_pop_idx=3):
        super().__init__()
        self.use_local_anc  = use_local_anc
        self.pool_to_blocks = True     # always True in v0.4+; flag kept for compat
        self.n_ld_blocks    = n_ld_blocks
        self.eur_pop_idx    = int(eur_pop_idx) if use_local_anc else -1

        self.embed = SNPEmbedding(
            n_ld_blocks, n_chrom, d_model,
            k_pops      = k_pops      if use_local_anc else 0,
            d_local     = d_local     if use_local_anc else 0,
            eur_pop_idx = eur_pop_idx if use_local_anc else -1
        )
        self.blocks = nn.ModuleList([
            GenoFormerBlock(d_model, n_heads, anc_dim, dropout)
            for _ in range(n_layers)
        ])
        self.cls_token = nn.Parameter(torch.randn(1, 1, d_model) * 0.02)
        self.prs_head  = nn.Sequential(
            nn.Linear(d_model, 64), nn.GELU(),
            nn.Dropout(dropout), nn.Linear(64, 1)
        )
        self.pop_head  = nn.Linear(d_model, anc_dim)

    def forward(self, dosage, log_beta, ld_block, chrom,
                global_anc, local_anc=None):
        B = dosage.shape[0]

        # SNPEmbedding now handles SNP→block reduction internally (v0.4)
        x = self.embed(
            dosage.unsqueeze(-1), log_beta.unsqueeze(-1),
            ld_block, chrom,
            local_anc if self.use_local_anc else None
        )                                                   # (B, n_ld_blocks, d_model)

        # Prepend CLS token and run transformer blocks
        cls = self.cls_token.expand(B, -1, -1)
        x   = torch.cat([cls, x], dim=1)                   # (B, n_blocks+1, d_model)
        for block in self.blocks:
            x = block(x, global_anc)

        cls_repr = x[:, 0]
        return self.prs_head(cls_repr).squeeze(-1), self.pop_head(cls_repr)


# ── Phased haplotype variant ───────────────────────────────────────────────────

class GenoFormerPhased(nn.Module):
    """
    Haplotype-aware variant — processes hap0 and hap1 separately through
    shared GenoFormer weights. PRS = hap0_prs + hap1_prs (additive diploid).
    """
    def __init__(self, **kwargs):
        super().__init__()
        self.base = GenoFormer(**kwargs)

    def forward(self, hap0_dos, hap1_dos, log_beta, ld_block, chrom,
                global_anc, hap0_local_anc, hap1_local_anc):
        prs0, pop0 = self.base(hap0_dos, log_beta, ld_block, chrom,
                               global_anc, hap0_local_anc)
        prs1, pop1 = self.base(hap1_dos, log_beta, ld_block, chrom,
                               global_anc, hap1_local_anc)
        return prs0 + prs1, (pop0 + pop1) / 2.0
