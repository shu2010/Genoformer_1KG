# genoformerR/inst/python/train.py  (v0.5.0)
# Training loop for GenoFormer — lazy per-batch tensor materialisation.
#
# v0.5: EUR-attenuation awareness in _make_batch.
#   When the static embedding cache is warm AND EUR attenuation is active,
#   log_beta must be sent as a real (B, M) tensor every batch — it is no
#   longer static because beta_proj receives log_beta × P(EUR|sample,snp).
#   When EUR attenuation is OFF, the v0.4 sentinel-zero optimisation is
#   preserved: log_beta and chrom are served from the cache and don't need
#   to be materialised per-batch.
#
# Key design change from v0.2:
#   Raw numpy arrays + split index vectors are received from R.
#   Tensors are built one batch at a time inside _make_batch(), so peak memory
#   is O(batch_size × M × K) rather than O(N × M × K).

import math
import time
import numpy as np
import torch
import torch.nn.functional as F

# ── tqdm with graceful fallback ────────────────────────────────────────────────
try:
    from tqdm import tqdm as _tqdm
    _HAS_TQDM = True
except ImportError:
    _HAS_TQDM = False


# ── Loss functions ─────────────────────────────────────────────────────────────

def prs_loss(pred, true):
    return F.mse_loss(pred, true)


def pop_loss(logits, labels):
    # R NA_integer_ arrives as -2147483648 (INT32_MIN). Filter those rows so a
    # stray NA never reaches cross_entropy and produces a cryptic IndexError.
    valid = labels >= 0
    if not valid.all():
        logits = logits[valid]
        labels = labels[valid]
    if labels.numel() == 0:
        return torch.tensor(0.0, device=logits.device)
    return F.cross_entropy(logits, labels)


def ancestry_calibration_loss(pred_prs, true_prs, anc_probs, n_pops=5):
    """
    Penalise heteroscedastic residuals across populations.
    anc_probs: (B, K) global ancestry fractions.
    """
    residuals = pred_prs - true_prs
    total = torch.tensor(0.0, device=pred_prs.device)
    for k in range(n_pops):
        w     = anc_probs[:, k]
        w_sum = w.sum() + 1e-8
        mu_r  = (w * residuals).sum() / w_sum
        var_r = (w * (residuals - mu_r) ** 2).sum() / w_sum
        total = total + var_r
    return total / n_pops


# ── Core training entry point ─────────────────────────────────────────────────

def train_genoformer(model,
                     dosage_mat,
                     anc_probs,
                     log_beta,
                     ld_blocks,
                     chroms,
                     local_anc      = None,
                     prs_scaled     = None,
                     pop_labels     = None,
                     tr_idx         = None,
                     va_idx         = None,
                     device         = "cpu",
                     epochs         = 100,
                     batch_size     = 64,
                     lr             = 1e-4,
                     weight_decay   = 0.01,
                     anc_weight     = 0.3,
                     calib_weight   = 0.5,
                     save_path      = None,
                     verbose        = True,
                     progress_bar   = True,
                     has_phenotype  = True,
                     early_stopping = True,
                     patience       = 10,
                     min_delta      = 1e-4):
    """
    Train GenoFormer (v0.3) with lazy per-batch tensor materialisation.

    Parameters
    ----------
    dosage_mat  : numpy (N, M) float — passed as-is from R, cast to float32 here
    anc_probs   : numpy (N, K) float
    log_beta    : numpy (M,)   float — 1-D; tiled to (B, M) inside _make_batch
    ld_blocks   : numpy (M,)   int   — 1-D; tiled to (B, M) inside _make_batch
    chroms      : numpy (M,)   int   — 1-D; tiled to (B, M) inside _make_batch
    local_anc   : numpy (N, M, K) float or None
    prs_scaled  : numpy (N,)   float or None  (pre-scaled in R)
    pop_labels  : numpy (N,)   int   or None
    tr_idx      : numpy (n_tr,) int  — 0-based row indices for training split
    va_idx      : numpy (n_va,) int  — 0-based row indices for validation split
    has_phenotype : bool — when False, PRS + calibration losses are skipped
    progress_bar  : bool — show tqdm epoch bar (requires tqdm package)
    """
    # ── Cast all inputs to float32 / int64 once ────────────────────────────
    # R passes float64 by default; casting here halves the numpy memory footprint
    # before any batching begins.
    dosage_np   = np.asarray(dosage_mat, dtype=np.float32)
    anc_np      = np.asarray(anc_probs,  dtype=np.float32)
    log_beta_np = np.asarray(log_beta,   dtype=np.float32)   # (M,)
    ld_np       = np.asarray(ld_blocks,  dtype=np.int64)     # (M,)
    ch_np       = np.asarray(chroms,     dtype=np.int64)     # (M,)
    local_np    = np.asarray(local_anc,  dtype=np.float32) if local_anc  is not None else None
    prs_np      = np.asarray(prs_scaled, dtype=np.float32) if prs_scaled is not None else None
    pop_np      = np.asarray(pop_labels, dtype=np.int64)   if pop_labels is not None else None

    tr_idx = np.asarray(tr_idx, dtype=np.int64)
    va_idx = np.asarray(va_idx, dtype=np.int64)

    has_local = local_np is not None
    has_pop   = pop_np   is not None

    # Mode label reflects supervision mode, ancestry conditioning, and EUR attenuation
    anc_mode   = "dual"   if has_local else "global"
    pheno_mode = "full"   if has_phenotype else "ancestry-only"
    eur_mode   = "+EUR-atten" if (has_local and _eur_attn) else ""
    mode_label = f"{pheno_mode} | {anc_mode}-anc{eur_mode}"

    # ── Lazy batch builder ─────────────────────────────────────────────────
    # When the static embedding cache is warm (precompute_static_embedding was
    # called), log_beta, ld_blocks, and chroms are not needed per-batch because
    # those projections have already been pooled to block level. Only dosage
    # (sample-specific) and local_anc (sample-specific) need to be assembled.
    # When the cache is absent (fallback), all tensors are built as before.
    _cache_warm   = model.embed._static_block_cache is not None
    _eur_attn     = getattr(model.embed, 'use_eur_attenuation', False)
    # When EUR attenuation is active, beta_proj depends on local_anc (sample-specific),
    # so log_beta must be materialised per-batch even when the static cache is warm.
    # When EUR attenuation is OFF, the v0.4 sentinel-zero optimisation is preserved.
    _need_lb_batch = (not _cache_warm) or _eur_attn

    def _make_batch(idx):
        b_size = len(idx)
        batch  = {
            "dosage":     torch.from_numpy(dosage_np[idx]).to(device),
            "global_anc": torch.from_numpy(anc_np[idx]).to(device),
        }
        # ld_block always needed for dosage pooling (and beta pooling under EUR attn)
        batch["ld_block"] = torch.from_numpy(
            np.tile(ld_np, (b_size, 1))).to(device)

        if _need_lb_batch:
            # Either cache is cold OR EUR attenuation requires per-sample log_beta
            batch["log_beta"] = torch.from_numpy(
                np.tile(log_beta_np, (b_size, 1))).to(device)
        else:
            # Cache is warm and EUR attenuation OFF → sentinel scalar, ignored by model
            batch["log_beta"] = torch.zeros(b_size, 1, dtype=torch.float32,
                                             device=device)

        if _cache_warm and not _eur_attn:
            # chrom served from static cache; sentinel scalar is sufficient
            batch["chrom"] = torch.zeros(b_size, 1, dtype=torch.int64, device=device)
        else:
            batch["chrom"] = torch.from_numpy(
                np.tile(ch_np, (b_size, 1))).to(device)

        if has_local:
            batch["local_anc"] = torch.from_numpy(local_np[idx]).to(device)
        if prs_np is not None:
            batch["prs"] = torch.from_numpy(prs_np[idx]).to(device)
        if has_pop:
            batch["pop"] = torch.from_numpy(pop_np[idx]).to(device)
        return batch

    def _iter_batches(idx_array, shuffle=True):
        """Yield index slices; materialise tensors only when consumed."""
        perm = np.random.permutation(len(idx_array)) if shuffle else np.arange(len(idx_array))
        idx_shuffled = idx_array[perm]
        for start in range(0, len(idx_shuffled), batch_size):
            yield _make_batch(idx_shuffled[start:start + batch_size])

    # ── Precompute static embedding cache ──────────────────────────────────
    # beta_proj, ld_emb, chr_emb are identical for every sample in every batch.
    # Pool them to block level once here and cache as (1, n_blocks, 3*quarter).
    # In the forward pass these are zero-copy expanded to (B, n_blocks, 3*quarter)
    # instead of being recomputed from (B, L, ...) each time.
    print("[genoformerR] Precomputing static embedding cache...")
    model.embed.precompute_static_embedding(
        torch.from_numpy(log_beta_np),
        torch.from_numpy(ld_np),
        torch.from_numpy(ch_np),
    )
    print("[genoformerR] Static cache ready.")

    # ── Runtime guard: verify model has pool_to_blocks ────────────────────
    # If the model object was built before model.py v0.3 was loaded (i.e. the
    # old GenoFormer class without pool_to_blocks), self.pool_to_blocks will
    # be missing. Full-SNP attention with L=5816 tokens produces a 34.6 GB
    # attention matrix per layer and causes VM thrashing — the epoch appears
    # frozen at 0% for hours without crashing. Detect and abort early.
    if not getattr(model, "pool_to_blocks", False):
        raise RuntimeError(
            "model.pool_to_blocks is False or missing. "
            "This model was built before the LD-block pooling fix (v0.3). "
            "Rebuild with gf_build_model(..., pool_to_blocks=TRUE) — "
            "without pooling, self-attention runs over all n_snps tokens "
            "and will exhaust memory on any standard instance."
        )

    # ── Loss composition ───────────────────────────────────────────────────
    def _compute_loss(pred_prs, pop_logits, batch):
        total = torch.tensor(0.0, device=pred_prs.device)
        if has_phenotype and "prs" in batch:
            total = total + prs_loss(pred_prs, batch["prs"])
            total = total + calib_weight * ancestry_calibration_loss(
                        pred_prs, batch["prs"], batch["global_anc"])
        if has_pop and "pop" in batch:
            total = total + anc_weight * pop_loss(pop_logits, batch["pop"])
        return total

    # ── Optimiser & scheduler ──────────────────────────────────────────────
    opt   = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs, eta_min=1e-6)

    best_val        = float("inf")
    history         = {"epoch": [], "train_loss": [], "val_loss": [], "lr": []}
    no_improve      = 0          # consecutive epochs without min_delta improvement
    stopped_early   = False
    epochs_run      = 0

    # ── Progress bar setup ─────────────────────────────────────────────────
    use_pbar = progress_bar and _HAS_TQDM
    if progress_bar and not _HAS_TQDM:
        print("[genoformerR] tqdm not found — install it for a progress bar "
              "(pip install tqdm). Falling back to verbose printing.")

    epoch_iter = _tqdm(
        range(1, epochs + 1),
        desc    = f"GenoFormer [{mode_label}]",
        unit    = "epoch",
        ncols   = 90,
        colour  = "cyan",
    ) if use_pbar else range(1, epochs + 1)

    # ── Training loop ──────────────────────────────────────────────────────
    n_tr_batches = math.ceil(len(tr_idx) / batch_size)
    n_va_batches = math.ceil(len(va_idx) / batch_size)
    first_batch_done = False

    for epoch in epoch_iter:

        # Train
        model.train()
        tr_loss, n_b = 0.0, 0
        t_epoch_start = time.time()

        batch_iter = _tqdm(
            _iter_batches(tr_idx, shuffle=True),
            total   = n_tr_batches,
            desc    = f"  train ep{epoch:03d}",
            leave   = False,
            ncols   = 80,
            disable = not use_pbar,
        ) if use_pbar else _iter_batches(tr_idx, shuffle=True)

        for batch in batch_iter:
            t_batch = time.time()
            pred_prs, pop_logits = model(
                batch["dosage"],   batch["log_beta"],
                batch["ld_block"], batch["chrom"],
                batch["global_anc"], batch.get("local_anc")
            )
            L = _compute_loss(pred_prs, pop_logits, batch)
            opt.zero_grad()
            L.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            tr_loss += L.item()
            n_b     += 1

            # After the very first batch, print a timing estimate so the user
            # knows training is alive and has an ETA before epoch 1 completes.
            if not first_batch_done:
                first_batch_done = True
                secs_per_batch = time.time() - t_batch
                secs_per_epoch = secs_per_batch * (n_tr_batches + n_va_batches)
                total_secs     = secs_per_epoch * epochs
                print(
                    f"\n[genoformerR] First batch: {secs_per_batch:.1f}s  |  "
                    f"~{secs_per_epoch/60:.1f} min/epoch  |  "
                    f"~{total_secs/3600:.1f} h total ({epochs} epochs)\n"
                )

        tr_loss /= max(n_b, 1)

        # Validate
        model.eval()
        va_loss, n_v = 0.0, 0
        with torch.no_grad():
            val_iter = _tqdm(
                _iter_batches(va_idx, shuffle=False),
                total   = n_va_batches,
                desc    = f"  val   ep{epoch:03d}",
                leave   = False,
                ncols   = 80,
                disable = not use_pbar,
            ) if use_pbar else _iter_batches(va_idx, shuffle=False)

            for batch in val_iter:
                pred_prs, pop_logits = model(
                    batch["dosage"],   batch["log_beta"],
                    batch["ld_block"], batch["chrom"],
                    batch["global_anc"], batch.get("local_anc")
                )
                L = _compute_loss(pred_prs, pop_logits, batch)
                va_loss += L.item()
                n_v     += 1
        va_loss /= max(n_v, 1)

        sched.step()
        cur_lr = sched.get_last_lr()[0]

        history["epoch"].append(epoch)
        history["train_loss"].append(round(tr_loss, 6))
        history["val_loss"].append(round(va_loss, 6))
        history["lr"].append(round(cur_lr, 8))

        # Checkpoint
        if va_loss < best_val - min_delta:
            best_val   = va_loss
            no_improve = 0
            if save_path:
                torch.save(model.state_dict(), save_path)
        else:
            no_improve += 1

        epochs_run = epoch

        # Update tqdm epoch bar postfix
        if use_pbar:
            pbar_fields = dict(
                train = f"{tr_loss:.4f}",
                val   = f"{va_loss:.4f}",
                lr    = f"{cur_lr:.1e}",
                best  = f"{best_val:.4f}",
            )
            if early_stopping:
                pbar_fields["patience"] = f"{no_improve}/{patience}"
            epoch_iter.set_postfix(**pbar_fields)

        # Verbose text fallback — every 10 epochs when no pbar
        if verbose and not use_pbar and epoch % 10 == 0:
            elapsed = (time.time() - t_epoch_start) / 60
            es_str  = f" | no_improve={no_improve}/{patience}" if early_stopping else ""
            print(f"[{mode_label}] Epoch {epoch:4d} | "
                  f"train={tr_loss:.4f} | val={va_loss:.4f} | "
                  f"lr={cur_lr:.2e} | {elapsed:.1f} min/epoch{es_str}")

        # Early stopping check
        if early_stopping and no_improve >= patience:
            msg = (f"\n[genoformerR] Early stopping at epoch {epoch} — "
                   f"val loss has not improved by >{min_delta:.0e} "
                   f"for {patience} consecutive epochs. "
                   f"Best val loss: {best_val:.6f}")
            if use_pbar:
                epoch_iter.write(msg)
            else:
                print(msg)
            stopped_early = True
            break

    return {"history": history, "best_val_loss": best_val, "epochs_run": epochs_run}
