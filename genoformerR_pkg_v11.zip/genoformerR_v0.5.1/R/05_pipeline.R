# genoformerR/R/05_pipeline.R  (v0.3.0)
# End-to-end wrapper — supports local_anc_method: "flare", "rfmix2",
# "windowed_pca", or "none"

#' Run the complete GenoFormer ancestry-aware PRS pipeline
#'
#' Orchestrates all steps from raw PLINK2 dosage files to evaluated PRS scores.
#' v0.3 replaces the separate \code{run_phasing} / \code{run_local_anc} flags
#' with a single \code{local_anc_method} argument.
#'
#' Supported local ancestry methods:
#' \describe{
#'   \item{\code{"flare"}}{Recommended. Java FLARE — no pre-phasing required,
#'     fast, biobank-scale. Requires \code{vcf_file}, \code{ref_vcf},
#'     \code{sample_map}, \code{gmap_dir}.}
#'   \item{\code{"rfmix2"}}{Legacy. Requires SHAPEIT4 pre-phasing and
#'     \code{vcf_file} (phased), \code{ref_vcf}, \code{sample_map},
#'     \code{gmap_dir}.}
#'   \item{\code{"windowed_pca"}}{Pure R — no external tools or reference panel.
#'     Slower for very large M, suitable for exploratory analyses.}
#'   \item{\code{"none"}}{Global-only conditioning (v0.1 behaviour).}
#' }
#'
#' @param dosage_raw        Character. Path to PLINK2 \code{.raw} dosage file.
#' @param pgs_file          Character. Path to PGS Catalog scoring file.
#' @param panel_file        Character. Path to 1KGP3 sample panel file.
#' @param phenotype         Numeric vector or path to phenotype file (2-col: ID, pheno).
#' @param outdir            Character. Output directory. Default \code{"genoformer_out"}.
#' @param is_1kg_cohort     Logical. TRUE when \code{dosage_raw} contains 1KGP3
#'   samples (base-model training scenario). FALSE for any external study cohort.
#'   Controls whether global and local ancestry use study-only PCA (Mode B,
#'   TRUE) or reference-projection PCA (Mode A, FALSE). When TRUE,
#'   \code{"flare"} is blocked because 1KGP3 cannot serve as its own FLARE
#'   reference panel. Default \code{TRUE}.
#' @param ref_dosage_raw    Character or NULL. Path to 1KGP3 LD-pruned \code{.raw}
#'   file for reference-based global ancestry projection. Required when
#'   \code{is_1kg_cohort = FALSE}. Ignored when \code{is_1kg_cohort = TRUE}.
#' @param local_anc_method  Character. One of \code{"flare"} (default for
#'   external cohorts), \code{"rfmix2"}, \code{"windowed_pca"}, or
#'   \code{"none"}. \code{"flare"} is only valid when
#'   \code{is_1kg_cohort = FALSE}.
#' @param vcf_file          Character or NULL. Study VCF (unphased for FLARE;
#'   phased for RFMix2). Required for \code{"flare"} and \code{"rfmix2"}.
#' @param ref_vcf           Character or NULL. Reference panel VCF. Required for
#'   \code{"flare"} and \code{"rfmix2"}.
#' @param sample_map        Character or NULL. 2-col TSV: sample_id, population.
#'   Required for \code{"flare"} and \code{"rfmix2"}.
#' @param gmap_dir          Character or NULL. Genetic map directory. Required for
#'   \code{"flare"} and \code{"rfmix2"}.
#' @param k_pops            Integer. Reference population count K. Default 5.
#'   For \code{"windowed_pca"}, sets the number of pseudo-ancestry dimensions.
#' @param flare_jar         Character. Path to \code{flare.jar}. Default
#'   \code{"flare.jar"}. Only used when \code{local_anc_method = "flare"}.
#' @param run_phasing       Logical. Run SHAPEIT4 before RFMix2. Only relevant
#'   when \code{local_anc_method = "rfmix2"}. Default FALSE.
#' @param pgen_prefix       Character or NULL. PLINK2 pgen prefix for phasing.
#'   Required when \code{run_phasing = TRUE}.
#' @param model_config      Named list. Passed to \code{\link{gf_build_model}}.
#' @param train_config      Named list. Passed to \code{\link{gf_train}}.
#' @param ancestry_method   Character. Global ancestry method: \code{"r"} or
#'   \code{"python"}. Default \code{"r"}.
#' @param device            Character. \code{"auto"}, \code{"cuda"}, or
#'   \code{"cpu"}. Default \code{"auto"}.
#' @param chroms            Integer vector. Chromosomes to process. Default 1:22.
#' @param seed              Integer. Random seed. Default 42.
#'
#' @return Named list: \code{ancestry}, \code{local_anc_arr}, \code{model},
#'   \code{history}, \code{prs}, \code{evaluation}, \code{paths}.
#' @export
#'
#' @examples
#' \dontrun{
#' # Global-only (no external tools)
#' gf_run_pipeline(dosage_raw="...", pgs_file="...", panel_file="...",
#'                 phenotype=pheno, local_anc_method="none")
#'
#' # FLARE (recommended for admixed cohorts)
#' gf_run_pipeline(dosage_raw="...", pgs_file="...", panel_file="...",
#'                 phenotype=pheno, local_anc_method="flare",
#'                 vcf_file="study.vcf.gz", ref_vcf="ref.vcf.gz",
#'                 sample_map="ref_panel.txt", gmap_dir="gmaps/",
#'                 flare_jar="flare.jar")
#'
#' # Windowed PCA (no external dependencies)
#' gf_run_pipeline(dosage_raw="...", pgs_file="...", panel_file="...",
#'                 phenotype=pheno, local_anc_method="windowed_pca",
#'                 k_pops=5L)
#' }
gf_run_pipeline <- function(dosage_raw,
                             pgs_file,
                             panel_file,
                             phenotype,
                             outdir           = "genoformer_out",
                             is_1kg_cohort    = TRUE,
                             ref_dosage_raw   = NULL,
                             local_anc_method = c("windowed_pca", "windowed_pca_centroid",
                                                   "flare", "rfmix2", "none"),
                             vcf_file         = NULL,
                             ref_vcf          = NULL,
                             sample_map       = NULL,
                             gmap_dir         = NULL,
                             k_pops           = 5L,
                             flare_jar        = "flare.jar",
                             run_phasing      = FALSE,
                             pgen_prefix      = NULL,
                             model_config     = list(),
                             train_config     = list(),
                             ancestry_method  = "r",
                             device           = "auto",
                             chroms           = 1:22,
                             seed             = 42L,
                             # windowed_pca_centroid-specific (mirrors gf_windowed_pca)
                             window_size          = 500L,
                             step_size            = NULL,
                             centroid_temperature = 1.0) {

  local_anc_method <- match.arg(local_anc_method)
  set.seed(seed)
  fs::dir_create(outdir)
  t0 <- proc.time()

  # ── Validate is_1kg_cohort / method combination ──────────────────────────────
  if (is_1kg_cohort && local_anc_method == "flare")
    cli::cli_abort(c(
      "local_anc_method='flare' is incompatible with is_1kg_cohort=TRUE.",
      "i" = "FLARE requires an independent reference panel.",
      "i" = "When the training cohort IS 1KGP3, using 1KGP3 as both query and",
      "i" = "reference contaminates FLARE's allele frequency emission estimates.",
      "i" = "Use local_anc_method='windowed_pca_centroid', 'windowed_pca', or 'none' for 1KGP3 base-model training."
    ))

  if (!is_1kg_cohort && local_anc_method %in% c("flare", "rfmix2")) {
    missing_args <- names(Filter(is.null,
      list(vcf_file = vcf_file, ref_vcf = ref_vcf,
           sample_map = sample_map, gmap_dir = gmap_dir)))
    if (length(missing_args) > 0)
      cli::cli_abort(
        "local_anc_method='{local_anc_method}' requires: {paste(missing_args, collapse=', ')}"
      )
  }

  if (!is_1kg_cohort && is.null(ref_dosage_raw))
    cli::cli_abort(c(
      "ref_dosage_raw= is required when is_1kg_cohort=FALSE.",
      "i" = "Supply the path to the 1KGP3 LD-pruned .raw file so that PCA is",
      "i" = "fitted on 1KGP3 and external samples are projected into that space."
    ))

  # ── Mode banner ─────────────────────────────────────────────────────────────
  mode_label <- c(
    flare                 = "FLARE (no phasing required)",
    rfmix2                = "RFMix2 (legacy, requires phasing)",
    windowed_pca          = "Windowed PCA (pure R, pseudo-ancestry axes)",
    windowed_pca_centroid = "Windowed PCA + Continental Centroids (interpretable K-pop probs)",
    none                  = "Global-only (no local ancestry)"
  )
  cli::cli_h1("GenoFormer v0.4.0 Pipeline")
  cli::cli_alert_info("Cohort: {.strong {if (is_1kg_cohort) '1KGP3 base model' else 'External study cohort'}}")
  cli::cli_alert_info("Local ancestry: {.strong {mode_label[local_anc_method]}}")

  # ── 0. Python backend ────────────────────────────────────────────────────────
  gf_init()

  # ── 1. Load dosage + PGS ─────────────────────────────────────────────────────
  cli::cli_alert_info("[1/6] Loading dosage matrix...")
  raw        <- data.table::fread(dosage_raw, nThread = 4L)
  sample_ids <- raw$IID
  dosage_mat <- as.matrix(raw[, -(1:6)])
  dosage_mat[is.na(dosage_mat)] <- 0L

  pgs       <- data.table::fread(pgs_file, skip = "#", nThread = 2L)
  names(pgs) <- tolower(names(pgs))
  w_col    <- intersect(c("effect_weight", "beta", "or"),     names(pgs))[1]
  ea_col   <- intersect(c("effect_allele", "a1"),             names(pgs))[1]
  id_col   <- intersect(c("rsid", "variant_id", "id", "snp"), names(pgs))[1]

  snp_ids        <- colnames(dosage_mat)
  pgs_matched    <- pgs[match(snp_ids, pgs[[id_col]]), ]
  pgs_weights    <- as.numeric(pgs_matched[[w_col]])
  effect_alleles <- as.character(pgs_matched[[ea_col]])
  chroms_snp     <- .snp_chroms(snp_ids)
  snp_positions  <- .snp_positions(snp_ids)
  ld_blocks      <- .assign_ld_blocks(snp_ids, chroms_snp)

  if (is.character(phenotype) && length(phenotype) == 1L && file.exists(phenotype)) {
    ph_df     <- data.table::fread(phenotype, nThread = 2L)
    phenotype <- as.numeric(ph_df[[2]][match(sample_ids, ph_df[[1]])])
  }
  stopifnot(length(phenotype) == length(sample_ids))

  # ── 2. Global ancestry ────────────────────────────────────────────────────────
  # is_1kg_cohort=TRUE  → Mode B: dosage_mat IS 1KGP3, IDs match panel directly.
  # is_1kg_cohort=FALSE → Mode A: project external samples into 1KGP3 PC space.
  cli::cli_alert_info("[2/6] Inferring global ancestry...")
  anc <- gf_ancestry(
    dosage_mat     = dosage_mat,
    panel_file     = panel_file,
    ref_dosage_raw = if (is_1kg_cohort) NULL else ref_dosage_raw,
    method         = ancestry_method
  )
  saveRDS(anc, file.path(outdir, "ancestry.rds"))

  # ── 3. Local ancestry ─────────────────────────────────────────────────────────
  cli::cli_alert_info("[3/6] Local ancestry — {local_anc_method}...")
  local_anc_arr <- NULL

  if (local_anc_method == "flare") {
    raw_prefixes <- gf_local_ancestry_flare(
      vcf_file   = vcf_file,
      ref_vcf    = ref_vcf,
      sample_map = sample_map,
      gmap_dir   = gmap_dir,
      outdir     = file.path(outdir, "flare"),
      chroms     = chroms,
      k_pops     = k_pops,
      flare_jar  = flare_jar
    )
    local_anc_arr <- gf_parse_flare(
      flare_prefixes = raw_prefixes,
      snp_ids        = snp_ids,
      snp_positions  = snp_positions,
      snp_chroms     = chroms_snp,
      sample_ids     = sample_ids,
      global_anc     = anc$anc_probs
    )

  } else if (local_anc_method == "rfmix2") {
    # Optional phasing step
    if (run_phasing) {
      if (is.null(pgen_prefix))
        cli::cli_abort("pgen_prefix required when run_phasing=TRUE")
      phased_vcfs <- gf_phase(
        pgen_prefix = pgen_prefix,
        outdir      = file.path(outdir, "phased"),
        gmap_dir    = gmap_dir,
        chroms      = chroms
      )
      study_vcf <- phased_vcfs
    } else {
      study_vcf <- vcf_file
    }
    raw_prefixes <- gf_local_ancestry_rfmix2(
      vcf_file   = study_vcf,
      ref_vcf    = ref_vcf,
      sample_map = sample_map,
      gmap_dir   = gmap_dir,
      outdir     = file.path(outdir, "rfmix2"),
      chroms     = chroms,
      k_pops     = k_pops
    )
    local_anc_arr <- gf_align_rfmix2(
      rfmix_prefixes = raw_prefixes,
      snp_ids        = snp_ids,
      snp_positions  = snp_positions,
      snp_chroms     = chroms_snp,
      sample_ids     = sample_ids,
      global_anc     = anc$anc_probs
    )

  } else if (local_anc_method == "windowed_pca") {
    # is_1kg_cohort=TRUE  → Mode B: study-only PCA on the 1KGP3 matrix directly.
    #   Do NOT pass ref_dosage_mat=; dosage_mat IS 1KGP3 so reference == study.
    # is_1kg_cohort=FALSE → Mode A: fit per-window PCA on 1KGP3 reference,
    #   project external samples in. Load ref from ref_dosage_raw.
    if (!is_1kg_cohort) {
      ref_raw_wp    <- data.table::fread(ref_dosage_raw, nThread = 4L)
      ref_dosage_wp <- as.matrix(ref_raw_wp[, -(1:6)])
      ref_dosage_wp[is.na(ref_dosage_wp)] <- 0
      storage.mode(ref_dosage_wp) <- "numeric"
    }
    local_anc_arr <- gf_windowed_pca(
      dosage_mat     = dosage_mat,
      snp_chroms     = chroms_snp,
      ref_dosage_mat = if (is_1kg_cohort) NULL else ref_dosage_wp,
      k_pops         = k_pops
    )
    # Save per-window prcomp objects — required to score new individuals later
    gf_save_window_pcas(local_anc_arr,
                         file.path(outdir, "window_pcas.rds"))

  } else if (local_anc_method == "windowed_pca_centroid") {
    # ── Centroid method: interpretable K-pop probabilities per SNP ─────────────
    # ref_ancestry: one superpop label per sample row of the REFERENCE dosage mat
    # snp_chroms is already derived from chroms_snp above and separates chromosomes.

    panel_data <- data.table::fread(panel_file, nThread = 2L)
    if (!"super_pop" %in% names(panel_data))
      cli::cli_abort("panel_file must contain a 'super_pop' column.")

    if (is_1kg_cohort) {
      # dosage_mat IS 1KGP3 — use it directly as both reference and query
      ref_geno_c  <- dosage_mat
      ref_ids_c   <- sample_ids
      ref_chroms_c <- chroms_snp
    } else {
      if (is.null(ref_dosage_raw))
        cli::cli_abort("ref_dosage_raw= required for windowed_pca_centroid when is_1kg_cohort=FALSE.")
      ref_raw_c    <- data.table::fread(ref_dosage_raw, nThread = 4L)
      ref_ids_c    <- ref_raw_c$IID
      ref_geno_c   <- as.matrix(ref_raw_c[, -(1:6)])
      ref_geno_c[is.na(ref_geno_c)] <- 0
      storage.mode(ref_geno_c) <- "numeric"
      ref_chroms_c <- .snp_chroms(colnames(ref_geno_c))
    }

    # Match reference sample IDs to panel superpop labels (one label per row)
    ref_pop_idx    <- match(ref_ids_c, panel_data$sample)
    ref_ancestry_c <- panel_data$super_pop[ref_pop_idx]
    n_labelled_c   <- sum(!is.na(ref_ancestry_c))
    if (n_labelled_c == 0L)
      cli::cli_abort("No reference sample IDs matched panel_file for windowed_pca_centroid.")
    if (n_labelled_c < length(ref_ids_c))
      cli::cli_warn(
        "{length(ref_ids_c) - n_labelled_c} reference samples have no panel label — excluded from centroid computation."
      )

    labelled_mask  <- !is.na(ref_ancestry_c)
    ref_geno_lab   <- ref_geno_c[labelled_mask, , drop = FALSE]
    ref_anc_lab    <- ref_ancestry_c[labelled_mask]

    cli::cli_alert_info(
      "windowed_pca_centroid: {sum(labelled_mask)} labelled ref samples, window={window_size} SNPs, step={step_size %||% window_size}"
    )

    # ── 1. Compute and freeze centroids (runs per-chromosome, keyed "chr:s") ──
    centroid_cache <- gf_compute_window_centroids(
      dosage_mat   = ref_geno_lab,
      ref_ancestry = ref_anc_lab,
      snp_chroms   = ref_chroms_c,
      superpops    = sort(unique(ref_anc_lab)),
      window_size  = as.integer(window_size),
      step_size    = step_size,
      k_pops       = as.integer(k_pops)
    )
    gf_save_window_centroids(centroid_cache,
                              file.path(outdir, "window_centroids.rds"))

    # ── 2. Assign ancestry probabilities for query (study) samples ────────────
    anc_result <- gf_assign_local_ancestry_centroid(
      dosage_mat     = dosage_mat,
      centroid_cache = centroid_cache,
      temperature    = centroid_temperature
    )

    # ── 3. Subset to PGS loci ─────────────────────────────────────────────────
    pgs_sub       <- gf_subset_ancestry_pgs(anc_result, snp_ids)
    local_anc_arr <- pgs_sub$ancestry_probs_pgs

    cli::cli_alert_info(
      "PGS coverage: {round(pgs_sub$coverage * 100, 1)}% ({length(pgs_sub$found_variants)} / {length(snp_ids)} variants)"
    )

  } else {
    cli::cli_alert_info("Local ancestry skipped — global-only conditioning.")
  }

  if (!is.null(local_anc_arr)) {
    saveRDS(local_anc_arr, file.path(outdir, "local_anc_array.rds"))
    dims <- paste(dim(local_anc_arr), collapse = " x ")
    cli::cli_alert_success("Local ancestry array: [{dims}]")
  }

  # ── 4. Build model ────────────────────────────────────────────────────────────
  cli::cli_alert_info("[4/6] Building GenoFormer...")
  use_local <- !is.null(local_anc_arr)
  # k_pops for model: infer from array if available
  k_model <- if (use_local) dim(local_anc_arr)[3] else k_pops
  model <- do.call(gf_build_model, c(
    list(n_snps        = ncol(dosage_mat),
         device        = device,
         use_local_anc = use_local,
         k_pops        = k_model),
    model_config
  ))

  # ── 5. Train ──────────────────────────────────────────────────────────────────
  cli::cli_alert_info("[5/6] Training GenoFormer...")
  pop_int <- as.integer(factor(anc$labels,
                               levels = c("AFR","AMR","EAS","EUR","SAS"))) - 1L
  trained <- do.call(gf_train, c(
    list(model        = model,
         dosage_mat   = dosage_mat,
         anc_probs    = anc$anc_probs,
         pgs_weights  = pgs_weights,
         ld_blocks    = ld_blocks,
         chroms       = chroms_snp,
         phenotype    = phenotype,
         pop_labels   = pop_int,
         local_anc    = local_anc_arr,
         save_path    = file.path(outdir, "genoformer_best.pt")),
    train_config
  ))
  model <- trained$model
  # Save weights + architecture config — both files are needed by gf_load_model()
  gf_save_model(model,
                path        = file.path(outdir, "genoformer_best.pt"),
                save_config = TRUE)
  write.csv(trained$history, file.path(outdir, "training_history.csv"),
            row.names = FALSE)

  # ── 6. PRS + evaluation ───────────────────────────────────────────────────────
  cli::cli_alert_info("[6/6] Computing and evaluating PRS...")
  prs <- gf_predict(
    model          = model,
    dosage_mat     = dosage_mat,
    anc_probs      = anc$anc_probs,
    pgs_weights    = pgs_weights,
    ld_blocks      = ld_blocks,
    chroms         = chroms_snp,
    effect_alleles = effect_alleles,
    local_anc      = local_anc_arr
  )
  prs$sample_id  <- sample_ids
  prs$population <- anc$labels
  write.csv(prs, file.path(outdir, "prs_scores.csv"), row.names = FALSE)

  eval_res <- gf_evaluate(prs, phenotype, anc$labels)
  ggplot2::ggsave(file.path(outdir, "portability.png"),
                  eval_res$portability_plot,  width = 8, height = 5, dpi = 150)
  ggplot2::ggsave(file.path(outdir, "distributions.png"),
                  eval_res$distribution_plot, width = 8, height = 6, dpi = 150)

  elapsed <- round((proc.time() - t0)["elapsed"] / 60, 1)
  cli::cli_alert_success(
    "Pipeline complete in {elapsed} min. Outputs: {.path {outdir}}"
  )

  list(
    ancestry      = anc,
    local_anc_arr = local_anc_arr,
    model         = model,
    history       = trained$history,
    prs           = prs,
    evaluation    = eval_res,
    paths         = list(
      outdir       = outdir,
      prs_csv      = file.path(outdir, "prs_scores.csv"),
      model_pt     = file.path(outdir, "genoformer_best.pt"),
      model_config = file.path(outdir, "genoformer_best_config.json"),
      ancestry_rds = file.path(outdir, "ancestry.rds"),
      window_pcas  = if (local_anc_method == "windowed_pca")
                       file.path(outdir, "window_pcas.rds") else NULL,
      history      = file.path(outdir, "training_history.csv")
    )
  )
}


# ── Internal SNP metadata helpers ──────────────────────────────────────────────

.snp_chroms <- function(snp_ids) {
  parsed <- suppressWarnings(
    as.integer(sub("^chr([0-9XY]+)[_:].*", "\\1", snp_ids))
  )
  if (all(is.na(parsed))) return(rep_len(1:22, length(snp_ids)))
  ifelse(is.na(parsed), 1L, parsed)
}

.snp_positions <- function(snp_ids) {
  parsed <- suppressWarnings(
    as.integer(sub("^chr[0-9XY]+[_:]([0-9]+)[_:].*", "\\1", snp_ids))
  )
  if (all(is.na(parsed))) return(seq_along(snp_ids) * 1000L)
  ifelse(is.na(parsed), seq_along(snp_ids) * 1000L, parsed)
}

.assign_ld_blocks <- function(snp_ids, chroms, block_size = 200L) {
  block_within_chr <- stats::ave(
    seq_along(snp_ids), chroms,
    FUN = function(x) ceiling(seq_along(x) / block_size)
  )
  as.integer(factor(paste(chroms, block_within_chr, sep = "_"))) - 1L
}
